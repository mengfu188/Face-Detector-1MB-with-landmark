//
// Created by cmf on 20-4-1.
//

#include <stdio.h>
#include <algorithm>
#include <vector>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/opencv.hpp>
#include <fstream>

#include "FaceDetector.h"


using namespace std;



static Timer timer;



void draw(cv::Mat &img, std::vector<bbox> boxes, float scale)
{
    // draw image
    for (int j = 0; j < boxes.size(); ++j) {
        cv::Rect rect(boxes[j].x1/scale, boxes[j].y1/scale, boxes[j].x2/scale - boxes[j].x1/scale, boxes[j].y2/scale - boxes[j].y1/scale);
        cv::rectangle(img, rect, cv::Scalar(0, 0, 255), 1, 8, 0);
        char test[80];
        sprintf(test, "%f", boxes[j].s);

        cv::putText(img, test, cv::Size((boxes[j].x1/scale), boxes[j].y1/scale), cv::FONT_HERSHEY_COMPLEX, 0.5, cv::Scalar(0, 255, 255));
        cv::circle(img, cv::Point(boxes[j].point[0]._x / scale, boxes[j].point[0]._y / scale), 1, cv::Scalar(0, 0, 225), 4);
        cv::circle(img, cv::Point(boxes[j].point[1]._x / scale, boxes[j].point[1]._y / scale), 1, cv::Scalar(0, 255, 225), 4);
        cv::circle(img, cv::Point(boxes[j].point[2]._x / scale, boxes[j].point[2]._y / scale), 1, cv::Scalar(255, 0, 225), 4);
        cv::circle(img, cv::Point(boxes[j].point[3]._x / scale, boxes[j].point[3]._y / scale), 1, cv::Scalar(0, 255, 0), 4);
        cv::circle(img, cv::Point(boxes[j].point[4]._x / scale, boxes[j].point[4]._y / scale), 1, cv::Scalar(255, 0, 0), 4);
    }
}

void join(cv::Mat &rgb, cv::Mat &gray, cv::Mat out)
{

}

int join(ncnn::Mat &img1, ncnn::Mat &img2, ncnn::Mat &top_blob)
{
    int dims = img1.dims;  // dims 3
    size_t elemsize = img1.elemsize;
    size_t elemsize2 = img2.elemsize;

    printf("img1 dims %d; elemsize %zu\n", dims, elemsize);

    int h = img1.h;
    int w = img1.w;

    int top_channels = 4;

    top_blob.create(w, h, top_channels, elemsize);
    if(top_blob.empty())
        return -100;

    size_t size = img1.cstep * img1.c;
    const unsigned char* ptr = img1;
    unsigned char* outptr = top_blob.channel(0);
    memcpy(outptr, ptr, size * elemsize);

    size_t size2 = img2.cstep;
    const unsigned  char* ptr2 = img2;
    unsigned  char * outptr2 = top_blob.channel(3);
    memcpy(outptr2, ptr2, size2 * elemsize2);

    return 0;

}

cv::Mat ncnn2cv(ncnn::Mat in, bool show= false){
    cv::Mat out(in.h, in.w, CV_8UC3);
    in.to_pixels(out.data, ncnn::Mat::PIXEL_BGR);
    if (show){
        cv::imshow("ncnn2cv", out);
        cv::waitKey(0);
    }
    return out;
}

ncnn::Mat cv2ncnn(cv::Mat img)
{
    ncnn::Mat out;
    out = ncnn::Mat::from_pixels(img.data, ncnn::Mat::PIXEL_BGR, img.cols, img.rows);
    return out;
}



int main(int argc, char** argv)
{

    timer.tic();
    string detector_param = "../model/faceDetector.param";
    string detector_bin = "../model/faceDetector.bin";
    const int max_side = 320;
    // slim or RFB
    Detector detector(detector_param, detector_bin, false);
    timer.toc("init detect model");

    timer.tic();
    string alive_param = "../model/FaceAnti-Spoofing.param";
    string alive_bin = "../model/FaceAnti-Spoofing.bin";
    ncnn::Net alive;
    alive.load_param(alive_param.c_str());
    alive.load_model(alive_bin.c_str());
    timer.toc("init alive model");

    timer.tic();
//    cv::VideoCapture cap1(0);
    cv::VideoCapture cap1("rtsp://admin:123456@192.168.1.20:554/profile2");
//    cv::VideoCapture cap2(2);

    cv::Mat img1, img2, img, combine;
    ncnn::Mat imgn1, imgn2, imgn, combinen;
    bool flag1, flag2;

    while (true)
    {

        flag1 = cap1.read(img1);
//        flag2 = cap2.read(img2);

        img = img1;

//        imgn1 = ncnn::Mat::from_pixels(img1.data, img1.type(), img1.cols, img1.rows);
        imgn1 = cv2ncnn(img1);

        join(imgn1, imgn2, combinen);

//        if (flag1==false or flag2==false)
//            break;

        cv::imshow("cap1", img1);
//        cv::imshow("cap2", img2);

        // scale
        float long_side = std::max(img.cols, img.rows);
        float scale = max_side/long_side;
        cv::Mat img_scale;
        cv::Size size = cv::Size(img.cols*scale, img.rows*scale);
        cv::resize(img, img_scale, cv::Size(img.cols*scale, img.rows*scale));

        std::vector<bbox> boxes;

        timer.tic();

        detector.Detect(img_scale, boxes);
        timer.toc("----total timer:");

        draw(img, boxes, scale);

        cv::imshow("cap1_det", img1);
//        cv::imshow("cap2_det")

        cv::waitKey(1);
    }




    return 0;
}
